# Web Pages
This directory contains web pages generated with the assist CLI manager. A page defines an entry file, a provider and other files to speed up development and provide more flexibility. A new page can be generated with this command;

```bash
    php assist new page < page name >
```

Replace < page name > with a desired page name.
