<?php
namespace Moorexa\Framework;

use Lightroom\Packager\Moorexa\MVC\Controller;
use function Lightroom\Templates\Functions\{render, redirect, json, view};
/**
 * Documentation for App Page can be found in App/readme.txt
 *
 *@package      App Page
 *@author       Moorexa <www.moorexa.com>
 *@author       Amadi Ifeanyi <amadiify.com>
 **/

class App extends Controller
{
    /**
    * @method App home
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/

    public function home() : void 
    {
        $this->view->render('home');
    }

    /**
    * @method App contact
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function contact() : void
    {
        $this->view->render('contact');
    }

    /**
    * @method App aboutUs
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function aboutUs() : void
    {
        $this->view->render('aboutus');
    }

    /**
    * @method App whatWeDo
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function whatWeDo() : void
    {
        $this->view->render('whatwedo');
    }

    /**
    * @method App whatWeDontDo
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function whatWeDontDo() : void
    {
        $this->view->render('whatwedontdo');
    }

    /**
    * @method App services
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function services() : void
    {
        $this->view->render('services');
    }

    /**
    * @method App faq
    *
    * See documentation https://www.moorexa.com/doc/controller
    *
    * You can catch params sent through the $_GET request
    * @return void
    **/
    public function faq() : void
    {
        $this->view->render('faq');
    }
}
// END class