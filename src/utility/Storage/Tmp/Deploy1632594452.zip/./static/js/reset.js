// manage data-toggle="pill"
let pills = document.querySelectorAll('*[data-toggle="pill"]');

// are we good ??
if (pills.length > 0)
{
    [].forEach.call(pills, (e)=>{
        e.addEventListener('click', ()=>{
            // get the href
            let tabPane = document.querySelector('#v-pills-tabContent');
            // console.log(tabPane.parentNode);
            window.scrollTo({
                top: tabPane.parentNode.offsetTop - 130,
                left: tabPane.parentNode.offsetLeft,
                behavior: 'smooth'
              });
        });
    });

    // load path name
    let pathName = location.pathname.replace(/^[\/]/, '').split('/');
    if (pathName.length == 2)
    {
        let pathTarget = pathName[1];

        // find now
        pathTarget = document.querySelector('*[href="#'+pathTarget+'"]');

        // can we click
        if (pathTarget !== null)
        {
            pathTarget.click();
        }
    }

    // manage data-if
    let dataIf = document.querySelectorAll('*[data-if]');
    if (dataIf.length > 0)
    {
        function check(e, val){
            if (this.value == val)
            {
                e.style.display = 'block';
            }
            else
            {
                e.style.display = 'none';
            }
        };

        [].forEach.call(dataIf, (e)=>{

            // get the attribute
            let attr = e.getAttribute('data-if').split('=');

            // can we continue
            if (attr.length > 1)
            {
                let attrElement = document.querySelector(attr[0]);

                // are we good?
                if (attrElement != null)
                {
                    attrElement.addEventListener('input', check.bind(attrElement, e, attr[1]));
                    attrElement.addEventListener('blur', check.bind(attrElement, e, attr[1]));
                    attrElement.addEventListener('change', check.bind(attrElement, e, attr[1]));
                }
            }
        });
    }
}