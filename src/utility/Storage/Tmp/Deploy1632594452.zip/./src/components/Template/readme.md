# Template
This directory contains the global header and footer files for all your views, 404, 204 error template file, no header and footer files.
 