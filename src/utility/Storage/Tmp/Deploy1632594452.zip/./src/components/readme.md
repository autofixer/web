# Components
This folder contains all html components for your application. Note: Partials may also include php classes. 