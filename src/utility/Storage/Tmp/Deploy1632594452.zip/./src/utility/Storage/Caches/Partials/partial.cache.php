<?php
return array (
  '4759deea91e5ffde2d776f2797a3388e_meta-tags.html' => '8b118b95a9843c320f625abd644bc834',
  'b96bdd91630abab3923c62bb2dcb2df5_specialize.html' => 'badb78527a4bced269424231d07ec8f6',
  '3e22358315074db226169ac0383dd643_testimonials.html' => 'dc8dfb12c1c713656d6833d9059ff20e',
  'e998df9990683e95e489b97b552d4a38_team.html' => 'de426e1870f996bc2ed93aaab959a096',
  '038900573ec50a6145dd2aaec2c90d4d_blog.html' => '05a265cec94ae0199146036efc8c77a0',
);
?>