<?php

namespace Masterminds\HTML5\Tests\Parser;

class EventStackError extends \Exception
{
}
