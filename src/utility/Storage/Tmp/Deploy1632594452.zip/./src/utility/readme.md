# Utility
This directory contains anything reusable. You can define custom services that can be used by your application here.