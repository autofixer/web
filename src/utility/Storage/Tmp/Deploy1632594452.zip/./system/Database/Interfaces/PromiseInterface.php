<?php
namespace Lightroom\Database\Interfaces;

/**
 * @package Database Query Promise Interface
 * @author Amadi Ifeanyi <amadiify.com>
 */
interface PromiseInterface
{

}