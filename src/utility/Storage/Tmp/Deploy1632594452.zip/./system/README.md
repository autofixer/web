# Moorexa Core Engine
This repo provides the core of the moorexa framework. You can visit [www.moorexa.com/roadmap] to see where we are headed next.

To use this repo, ensure you have [https://github.com/moorexa/micro] or [https://github.com/moorexa/default] pulled 
to your machine, download this repo and merge with the root ```system/``` directory.