<?php
namespace Lightroom\Router\Interfaces;

/**
 * @package RouterInterface
 * @author Amadi Ifeanyi <amadiify.com>
 */
interface RouterInterface
{

}