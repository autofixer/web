<?php
namespace Lightroom\Exceptions;

use Exception;

/**
 * @package autoload register exception
 * @author Amadi Ifeanyi <amadiify.com>
 */
class AutoloadRegisterException extends Exception
{
    
}