<?php
namespace Lightroom\Common\Interfaces;

/**
 * @package Exception Wrapper Interface
 */
interface ExceptionWrapperInterface
{
    
}